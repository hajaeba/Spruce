// server.js
require('dotenv').config();
const express = require('express');
const session = require('express-session');
const bcrypt = require('bcrypt');
const path = require('path');
const pool = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;

app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
  secret: process.env.SESSION_SECRET || 'secret',
  resave: false,
  saveUninitialized: false,
}));

// Middleware: require login
function auth(req, res, next) {
  if (!req.session.user) return res.redirect('/login');
  next();
}

// --- ROUTES ---

app.get('/', (req, res) => {
  res.redirect('/home');
});

// Register
app.get('/register', (req, res) => res.render('register', { error: null }));
app.post('/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;
    const hashed = await bcrypt.hash(password, 10);
    await pool.query('INSERT INTO users (name, email, password) VALUES (?, ?, ?)', [name, email, hashed]);
    res.redirect('/login');
  } catch (err) {
    console.error(err);
    res.render('register', { error: 'Email may already be used or invalid input.' });
  }
});

// Login
app.get('/login', (req, res) => res.render('login', { error: null }));
app.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
    if (!rows.length) return res.render('login', { error: 'No user found' });

    const user = rows[0];
    const valid = await bcrypt.compare(password, user.password);
    if (!valid) return res.render('login', { error: 'Wrong password' });

    // remove password before storing in session
    delete user.password;
    req.session.user = user;
    res.redirect('/home');
  } catch (err) {
    console.error(err);
    res.render('login', { error: 'Something went wrong' });
  }
});

// Logout
app.post('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/login'));
});

// Home - show posts + create post
app.get('/home', auth, async (req, res) => {
  const [posts] = await pool.query(
    `SELECT posts.*, users.name AS author
     FROM posts JOIN users ON posts.user_id = users.id
     ORDER BY posts.created_at DESC`
  );

  // fetch counts for likes & comments (simple implementation)
  const [likes] = await pool.query('SELECT post_id, COUNT(*) AS cnt FROM likes GROUP BY post_id');
  const likeMap = Object.fromEntries(likes.map(l => [l.post_id, l.cnt]));

  const [comments] = await pool.query('SELECT post_id, COUNT(*) AS cnt FROM comments GROUP BY post_id');
  const commentMap = Object.fromEntries(comments.map(c => [c.post_id, c.cnt]));

  res.render('home', { user: req.session.user, posts, likeMap, commentMap });
});

app.post('/posts', auth, async (req, res) => {
  await pool.query('INSERT INTO posts (user_id, content) VALUES (?, ?)', [req.session.user.id, req.body.content]);
  res.redirect('/home');
});

// Comment: insert comment and notify post owner (if not commenter)
app.post('/posts/:id/comment', auth, async (req, res) => {
  const postId = req.params.id;
  const text = req.body.text;
  const userId = req.session.user.id;

  await pool.query('INSERT INTO comments (post_id, user_id, text) VALUES (?, ?, ?)', [postId, userId, text]);

  const [[post]] = await pool.query('SELECT user_id FROM posts WHERE id = ?', [postId]);
  if (post && post.user_id !== userId) {
    await pool.query('INSERT INTO notifications (user_id, type, message) VALUES (?, ?, ?)', [
      post.user_id, 'comment', `${req.session.user.name} commented on your post`
    ]);
  }

  res.redirect('/home');
});

// Like: insert like (unique per user-post) and notify post owner
app.post('/posts/:id/like', auth, async (req, res) => {
  const postId = req.params.id;
  const userId = req.session.user.id;

  try {
    await pool.query('INSERT INTO likes (post_id, user_id) VALUES (?, ?)', [postId, userId]);
  } catch (err) {
    // ignore duplicate like due to unique constraint
  }

  const [[post]] = await pool.query('SELECT user_id FROM posts WHERE id = ?', [postId]);
  if (post && post.user_id !== userId) {
    await pool.query('INSERT INTO notifications (user_id, type, message) VALUES (?, ?, ?)', [
      post.user_id, 'like', `${req.session.user.name} liked your post`
    ]);
  }

  res.redirect('/home');
});

// Notifications list + mark as read endpoint
app.get('/notifications', auth, async (req, res) => {
  const [notes] = await pool.query('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC', [req.session.user.id]);
  res.render('notifications', { user: req.session.user, notes });
});

app.post('/notifications/:id/read', auth, async (req, res) => {
  await pool.query('UPDATE notifications SET is_read=1 WHERE id = ? AND user_id = ?', [req.params.id, req.session.user.id]);
  res.redirect('/notifications');
});

// Messaging: view conversation with a user
app.get('/messages/:id', auth, async (req, res) => {
  const otherId = parseInt(req.params.id, 10);
  const me = req.session.user.id;

  const [messages] = await pool.query(
    `SELECT m.*, s.name AS sender_name
     FROM messages m
     JOIN users s ON m.sender_id = s.id
     WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)
     ORDER BY m.created_at ASC`,
    [me, otherId, otherId, me]
  );

  // get other user name
  const [[other]] = await pool.query('SELECT id, name FROM users WHERE id = ?', [otherId]);

  res.render('messages', { user: req.session.user, messages, other });
});

// Send message + notify receiver
app.post('/messages/:id', auth, async (req, res) => {
  const receiver = req.params.id;
  const sender = req.session.user.id;
  const message = req.body.message;

  await pool.query('INSERT INTO messages (sender_id, receiver_id, message) VALUES (?, ?, ?)', [sender, receiver, message]);

  await pool.query('INSERT INTO notifications (user_id, type, message) VALUES (?, ?, ?)', [
    receiver, 'message', `${req.session.user.name} sent you a message`
  ]);

  res.redirect(`/messages/${receiver}`);
});

// Simple user list to click and message (for demo)
app.get('/users', auth, async (req, res) => {
  const [users] = await pool.query('SELECT id, name FROM users WHERE id <> ?', [req.session.user.id]);
  res.render('user_list', { user: req.session.user, users });
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));

