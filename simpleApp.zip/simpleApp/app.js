require('dotenv').config();
const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const mysql = require('mysql2/promise');
const app = express();
const PORT = process.env.PORT || 3000;
// DB config from .env
const dbConfig = {
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || 'root',
    database: process.env.DB_NAME || 'simple_social',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
};

// logged-in user simulated via .env
const LOGGED_IN_USER_ID = parseInt(process.env.LOGGED_IN_USER_ID || '1', 10);

// view engine
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

// helper - get pool
const pool = mysql.createPool(dbConfig);
/* ROUTES */

// Home - list posts + show follower count in header
app.get('/', async (req, res) => {
    const conn = await pool.getConnection();
    try {
        const [posts] = await conn.execute(
            `SELECT p.id, p.title, p.body, p.created_at, u.username
       FROM posts p LEFT JOIN users u ON p.user_id = u.id
       ORDER BY p.created_at DESC`
        );
        // compute follower count using followers table
        const [rows] = await conn.execute(
            `SELECT COUNT(*) as follower_count FROM followers WHERE user_id = ?`,
            [LOGGED_IN_USER_ID]
        );
        const follower_count = rows[0] ? rows[0].follower_count : 0;

        res.render('posts', { posts, follower_count });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server error');
    } finally {
        conn.release();
    }
});
// View a single post with comments
app.get('/post/:id', async (req, res) => {
    const postId = req.params.id;
    const conn = await pool.getConnection();
    try {
        const [[post]] = await conn.execute(
            `SELECT p.id, p.title, p.body, p.created_at, u.username
       FROM posts p LEFT JOIN users u ON p.user_id = u.id
       WHERE p.id = ?`, [postId]
        );
        if (!post) return res.status(404).send('Post not found');

        const [comments] = await conn.execute(
            `SELECT c.id, c.content, c.created_at, u.username
       FROM comments c LEFT JOIN users u ON c.user_id = u.id
       WHERE c.post_id = ?
       ORDER BY c.created_at ASC`, [postId]
        );
        const [rows] = await conn.execute(
            `SELECT COUNT(*) as follower_count FROM followers WHERE user_id = ?`,
            [LOGGED_IN_USER_ID]
        );
        const follower_count = rows[0] ? rows[0].follower_count : 0;

        res.render('post', { post, comments, follower_count });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server error');
    } finally {
        conn.release();
    }
});
// Submit a comment
app.post('/post/:id/comment', async (req, res) => {
    const postId = req.params.id;
    const content = (req.body.content || '').trim();
    if (!content) {
        return res.redirect(`/post/${postId}`);
    }

    const conn = await pool.getConnection();
    try {
        await conn.execute(
            `INSERT INTO comments (post_id, user_id, content) VALUES (?, ?, ?)`,
            [postId, LOGGED_IN_USER_ID, content]
        );
        res.redirect(`/post/${postId}`);
    } catch (err) {
        console.error(err);
        res.status(500).send('Error saving comment');
    } finally {
        conn.release();
    }
});
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});